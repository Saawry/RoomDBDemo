package com.example.roomdatabasedemo;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;
import android.support.annotation.NonNull;

import java.util.List;

public class ProductViewModel extends AndroidViewModel {

    private ProductRepository productRepository;
    private LiveData<List<Product>> allProducts;

    public ProductViewModel(@NonNull Application application) {
        super(application);
        productRepository = new ProductRepository(application);
        allProducts = productRepository.getAllProducts();
    }


    void insertProduct(Product product) {
        productRepository.insert(product);
    }

    void deleteProduct(Product product) {
        productRepository.delete(product);
    }

    void updateProduct(Product product) {
        productRepository.update(product);
    }

    LiveData<List<Product>> getAllProducts() {
        return allProducts;
    }

    void deleteAllProducts() {
        productRepository.deleteAllProducts();
    }


}
